<?php

declare(strict_types=1);

use Illuminate\Foundation\Testing\RefreshDatabase;
use MasyukAI\Cart\Facades\Cart;

uses(RefreshDatabase::class);

beforeEach(function () {
    // Set up database storage for this test
    config(['cart.storage' => 'database']);

    // Run the cart migration
    $this->artisan('migrate', ['--force' => true]);

    // Clear cart between tests
    Cart::clear();
});

it('prevents race conditions with lockForUpdate enabled', function () {
    config(['cart.database.lock_for_update' => true]);

    // Add initial item to cart
    Cart::add('1', 'Product 1', 100, 1);

    // Verify item was added
    expect(Cart::content())->toHaveCount(1);
    expect(Cart::get('1')->quantity)->toBe(1);

    // Simulate concurrent update scenario
    // In a real scenario, this would involve multiple processes
    // Here we simulate by directly calling storage methods

    $storage = Cart::storage();
    $identifier = session()->getId();
    $instance = 'default';

    // Get current items
    $items = $storage->getItems($identifier, $instance);
    expect($items)->toHaveCount(1);

    // Modify quantity
    $items['1']['quantity'] = 2;

    // This should work with lockForUpdate - no conflicts expected
    $storage->putItems($identifier, $instance, $items);

    // Verify the update
    $updatedItems = $storage->getItems($identifier, $instance);
    expect($updatedItems['1']['quantity'])->toBe(2);

    // Also verify through Cart facade
    expect(Cart::get('1')->quantity)->toBe(2);
});

it('handles concurrent condition updates with lockForUpdate', function () {
    config(['cart.database.lock_for_update' => true]);

    // Add a condition to the cart
    Cart::addCondition(new \MasyukAI\Cart\Conditions\CartCondition('Tax', 'tax', 'subtotal', '10%'));

    // Verify condition was added
    expect(Cart::getConditions())->toHaveCount(1);

    $storage = Cart::storage();
    $identifier = session()->getId();
    $instance = 'default';

    // Add another condition through storage
    $conditions = $storage->getConditions($identifier, $instance);
    $conditions['discount'] = [
        'name' => 'Discount',
        'type' => 'discount',
        'target' => 'subtotal',
        'value' => '-5%',
    ];

    // This should work without conflicts
    $storage->putConditions($identifier, $instance, $conditions);

    // Verify both conditions exist
    expect(Cart::getConditions())->toHaveCount(2);
    expect(Cart::getCondition('Tax'))->not()->toBeNull();
});

it('metadata updates work with lockForUpdate', function () {
    config(['cart.database.lock_for_update' => true]);

    // Add an item first to create the cart record
    Cart::add('1', 'Product 1', 100, 1);

    $storage = Cart::storage();
    $identifier = session()->getId();
    $instance = 'default';

    // Add metadata
    $storage->putMetadata($identifier, $instance, 'customer_notes', 'Special instructions');
    $storage->putMetadata($identifier, $instance, 'promo_code', 'SAVE10');

    // Verify metadata
    expect($storage->getMetadata($identifier, $instance, 'customer_notes'))->toBe('Special instructions');
    expect($storage->getMetadata($identifier, $instance, 'promo_code'))->toBe('SAVE10');
});

it('can disable lockForUpdate for maximum performance', function () {
    config(['cart.database.lock_for_update' => false]);

    // Add initial item to cart
    Cart::add('1', 'Product 1', 100, 1);

    // Verify normal operations still work without locking
    expect(Cart::content())->toHaveCount(1);

    // Update quantity
    Cart::update('1', ['quantity' => 3]);
    expect(Cart::get('1')->quantity)->toBe(3);

    // Add condition
    Cart::addCondition(new \MasyukAI\Cart\Conditions\CartCondition('Tax', 'tax', 'subtotal', '10%'));

    expect(Cart::getConditions())->toHaveCount(1);
});
