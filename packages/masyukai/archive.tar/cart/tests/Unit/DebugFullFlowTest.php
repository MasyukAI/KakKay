<?php

declare(strict_types=1);

use MasyukAI\Cart\Cart;
use MasyukAI\Cart\PriceTransformers\IntegerPriceTransformer;
use MasyukAI\Cart\Services\PriceFormatterService;
use MasyukAI\Cart\Storage\SessionStorage;
use MasyukAI\Cart\Support\PriceFormatManager;

it('debug full flow with integer transformer (config-independent)', function () {
    // Ensure formatting is disabled to get raw numeric values
    PriceFormatManager::disableFormatting();
    PriceFormatManager::resetFormatting();

    // Create explicit integer transformer and formatter (no config dependency)
    $transformer = new IntegerPriceTransformer('USD', 'en_US', 2);
    $formatter = new PriceFormatterService($transformer);

    // Test direct transformer behavior
    $stored = $transformer->toStorage(19.99);
    expect($stored)->toBe(1999);
    $displayed = $transformer->toDisplay($stored);
    expect($displayed)->toBe('19.99');

    // Test formatter behavior
    $formatterStored = $formatter->normalize(19.99);
    expect($formatterStored)->toBe(1999);
    $formatterDisplayed = $formatter->format($formatterStored);
    expect($formatterDisplayed)->toBe('19.99');

    // Create cart with explicit dependencies (no config)
    $session = app('session')->driver();
    $storage = new SessionStorage($session, 'debug_test');
    $cart = new Cart(
        storage: $storage,
        events: new \Illuminate\Events\Dispatcher,
        instanceName: 'debug_test',
        eventsEnabled: false
    );

    // Test cart operations
    $cart->add('item-1', 'Test Item', 19.99, 1);
    $item = $cart->get('item-1');

    // Cart stores the price as given (no automatic transformation)
    expect($item->price)->toBe(19.99);
    // With formatting disabled, cart should return float values
    expect($cart->subtotal()->getMajorUnits())->toBe(19.99);

    // But we can transform manually using our formatter
    $itemPriceInCents = $formatter->normalize($item->price);
    expect($itemPriceInCents)->toBe(1999);

    $subtotalInCents = $formatter->normalize($cart->subtotal()->getMajorUnits());
    expect($subtotalInCents)->toBe(1999);

    // And convert back to display
    expect($formatter->format($itemPriceInCents))->toBe('19.99');
    expect($formatter->format($subtotalInCents))->toBe('19.99');

    // This demonstrates that the IntegerPriceTransformer works correctly
    // for cent-based storage systems, even though the cart itself
    // stores prices in their input format
});
