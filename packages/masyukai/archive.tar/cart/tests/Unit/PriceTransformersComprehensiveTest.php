<?php

declare(strict_types=1);

use MasyukAI\Cart\Cart;
use MasyukAI\Cart\PriceTransformers\DecimalPriceTransformer;
use MasyukAI\Cart\PriceTransformers\IntegerPriceTransformer;
use MasyukAI\Cart\Services\PriceFormatterService;
use MasyukAI\Cart\Storage\SessionStorage;

describe('Price Transformers Comprehensive Test (Config-Independent)', function () {

    describe('IntegerPriceTransformer Direct Testing', function () {
        beforeEach(function () {
            $this->transformer = new IntegerPriceTransformer('USD', 'en_US', 2);
        });

        it('handles storage format correctly for integer storage', function () {
            // Test basic cent storage (1999 = $19.99)
            expect($this->transformer->toStorage(19.99))->toBe(1999);
            expect($this->transformer->toStorage('19.99'))->toBe(1999);
            expect($this->transformer->toStorage(0.01))->toBe(1);
            expect($this->transformer->toStorage(100.00))->toBe(10000);
        });

        it('handles display format correctly for integer storage', function () {
            // Test conversion from cents to dollars for display
            expect($this->transformer->toDisplay(1999))->toBe('19.99');
            expect($this->transformer->toDisplay(1))->toBe('0.01');
            expect($this->transformer->toDisplay(10000))->toBe('100.00');
            expect($this->transformer->toDisplay(0))->toBe('0.00');
        });

        it('handles numeric conversion correctly for integer storage', function () {
            // Test conversion from cents to float for calculations
            expect($this->transformer->toNumeric(1999))->toBe(19.99);
            expect($this->transformer->toNumeric(1))->toBe(0.01);
            expect($this->transformer->toNumeric(10000))->toBe(100.00);
            expect($this->transformer->toNumeric(0))->toBe(0.0);
        });

        it('maintains round-trip consistency for integer storage', function () {
            $testPrices = [0.01, 0.99, 1.00, 19.99, 100.00, 999.99];

            foreach ($testPrices as $price) {
                $stored = $this->transformer->toStorage($price);
                $numeric = $this->transformer->toNumeric($stored);

                expect(abs($numeric - $price))->toBeLessThan(0.01);
            }
        });
    });

    describe('DecimalPriceTransformer Direct Testing', function () {
        beforeEach(function () {
            $this->transformer = new DecimalPriceTransformer('USD', 'en_US', 2);
        });

        it('handles storage format correctly for decimal storage', function () {
            // Test decimal storage (19.99 = 19.99)
            expect($this->transformer->toStorage(19.99))->toBe(19.99);
            expect($this->transformer->toStorage('19.99'))->toBe(19.99);
            expect($this->transformer->toStorage(0.01))->toBe(0.01);
            expect($this->transformer->toStorage(100.00))->toBe(100.00);
        });

        it('handles display format correctly for decimal storage', function () {
            // Test conversion from decimal to display
            expect($this->transformer->toDisplay(19.99))->toBe('19.99');
            expect($this->transformer->toDisplay(0.01))->toBe('0.01');
            expect($this->transformer->toDisplay(100.00))->toBe('100.00');
            expect($this->transformer->toDisplay(0))->toBe('0.00');
        });

        it('handles numeric conversion correctly for decimal storage', function () {
            // Test conversion from decimal to float for calculations
            expect($this->transformer->toNumeric(19.99))->toBe(19.99);
            expect($this->transformer->toNumeric(0.01))->toBe(0.01);
            expect($this->transformer->toNumeric(100.00))->toBe(100.00);
            expect($this->transformer->toNumeric(0))->toBe(0.0);
        });
    });

    describe('PriceFormatterService with Fixed Transformers', function () {
        it('works correctly with IntegerPriceTransformer', function () {
            $transformer = new IntegerPriceTransformer('USD', 'en_US', 2);
            $formatter = new PriceFormatterService($transformer);

            // Test normalization (input -> storage format)
            expect($formatter->normalize(19.99))->toBe(1999);
            expect($formatter->normalize('19.99'))->toBe(1999);

            // Test formatting (storage -> display format)
            expect($formatter->format(1999))->toBe('19.99');
            expect($formatter->format(1999.0))->toBe('19.99');

            // Test calculation handling (storage -> numeric for calculations)
            expect($formatter->calculate(1999))->toBe(19.99); // Convert cents to dollars for calculation
            expect($formatter->calculate(550))->toBe(5.50);   // $5.50 in cents

            // Test combined operations
            $price1Storage = $formatter->normalize(19.99); // 1999 cents
            $price2Storage = $formatter->normalize(5.50);  // 550 cents
            $totalCents = $price1Storage + $price2Storage; // 2549 cents
            expect($formatter->calculate($totalCents))->toBe(25.49); // $25.49
        });

        it('works correctly with DecimalPriceTransformer', function () {
            $transformer = new DecimalPriceTransformer('USD', 'en_US', 2);
            $formatter = new PriceFormatterService($transformer);

            // Test normalization (input -> storage format)
            expect($formatter->normalize(19.99))->toBe(19.99);
            expect($formatter->normalize('19.99'))->toBe(19.99);

            // Test formatting (storage -> display format)
            expect($formatter->format(19.99))->toBe('19.99');

            // Test calculation handling (storage -> numeric for calculations)
            expect($formatter->calculate(19.99))->toBe(19.99);
            expect($formatter->calculate(5.50))->toBe(5.50);

            // Test combined operations
            $price1Storage = $formatter->normalize(19.99); // 19.99
            $price2Storage = $formatter->normalize(5.50);  // 5.50
            $total = $price1Storage + $price2Storage;      // 25.49
            expect($formatter->calculate($total))->toBe(25.49);
        });
    });

    describe('Cart Integration with Fixed Transformers', function () {
        it('works correctly with IntegerPriceTransformer in cart calculations', function () {
            // Create cart with explicit storage and no config dependency
            $session = app('session')->driver(); // Get actual session driver
            $storage = new SessionStorage($session, 'cart_integer_test');
            $cart = new Cart(
                storage: $storage,
                events: new \Illuminate\Events\Dispatcher,
                instanceName: 'integer_test',
                eventsEnabled: false
            );

            // Create explicit formatter with IntegerPriceTransformer
            $transformer = new IntegerPriceTransformer('USD', 'en_US', 2);
            $formatter = new PriceFormatterService($transformer);

            // Test direct cart operations (no formatting)
            $cart->add('item-1', 'Test Item', 19.99, 1);
            $item = $cart->get('item-1');

            // Item should store price as given (19.99 in this case since cart doesn't auto-convert)
            expect($item->price)->toBe(19.99);
            expect($cart->subtotal()->getMajorUnits())->toBe(19.99);

            // Test manual transformation
            $storedPrice = $transformer->toStorage(19.99);
            expect($storedPrice)->toBe(1999);
            $displayPrice = $transformer->toDisplay($storedPrice);
            expect($displayPrice)->toBe('19.99');
        });

        it('works correctly with DecimalPriceTransformer in cart calculations', function () {
            // Create cart with explicit storage and no config dependency
            $session = app('session')->driver(); // Get actual session driver
            $storage = new SessionStorage($session, 'cart_decimal_test');
            $cart = new Cart(
                storage: $storage,
                events: new \Illuminate\Events\Dispatcher,
                instanceName: 'decimal_test',
                eventsEnabled: false
            );

            // Create explicit formatter with DecimalPriceTransformer
            $transformer = new DecimalPriceTransformer('USD', 'en_US', 2);
            $formatter = new PriceFormatterService($transformer);

            // Test direct cart operations
            $cart->add('item-1', 'Test Item', 19.99, 1);
            $item = $cart->get('item-1');

            expect($item->price)->toBe(19.99);
            expect($cart->subtotal()->getMajorUnits())->toBe(19.99);

            // Test manual transformation
            $storedPrice = $transformer->toStorage(19.99);
            expect($storedPrice)->toBe(19.99);
            $displayPrice = $transformer->toDisplay($storedPrice);
            expect($displayPrice)->toBe('19.99');
        });
    });

    describe('Storage Format Awareness Tests', function () {
        it('detects the need for integer vs decimal transformers based on usage', function () {
            // These tests validate that the cart can work with both storage formats

            // Integer storage scenario (database stores prices as cents)
            $integerTransformer = new IntegerPriceTransformer('USD', 'en_US', 2);
            $prices = [19.99, 5.50, 100.00, 0.01];

            foreach ($prices as $price) {
                $stored = $integerTransformer->toStorage($price);
                $retrieved = $integerTransformer->toNumeric($stored);
                $displayed = $integerTransformer->toDisplay($stored);

                // Should be stored as integers (cents)
                expect($stored)->toBeInt();
                // Should retrieve as the original float
                expect(abs($retrieved - $price))->toBeLessThan(0.01);
                // Should display correctly
                expect($displayed)->toBe(number_format($price, 2));
            }

            // Decimal storage scenario (database stores prices as decimals)
            $decimalTransformer = new DecimalPriceTransformer('USD', 'en_US', 2);

            foreach ($prices as $price) {
                $stored = $decimalTransformer->toStorage($price);
                $retrieved = $decimalTransformer->toNumeric($stored);
                $displayed = $decimalTransformer->toDisplay($stored);

                // Should be stored as floats
                expect($stored)->toBeFloat();
                // Should retrieve as the original float
                expect(abs($retrieved - $price))->toBeLessThan(0.01);
                // Should display correctly
                expect($displayed)->toBe(number_format($price, 2));
            }
        });
    });

    describe('Precision and Rounding Tests', function () {
        it('handles Money precision correctly with IntegerPriceTransformer', function () {
            $transformer = new IntegerPriceTransformer('USD', 'en_US', 2);

            // Test edge cases that might cause precision issues
            $edgeCases = [
                19.995,  // Should round to 20.00 (2000 cents)
                19.994,  // Should round to 19.99 (1999 cents)
                0.005,   // Should round to 0.01 (1 cent)
                0.004,   // Should round to 0.00 (0 cents)
            ];

            foreach ($edgeCases as $price) {
                $stored = $transformer->toStorage($price);
                $displayed = $transformer->toDisplay($stored);

                // Should be properly rounded integers
                expect($stored)->toBeInt();
                // Display should show proper decimal places
                expect($displayed)->toMatch('/^\d+\.\d{2}$/');
            }
        });

        it('handles Money precision correctly with DecimalPriceTransformer', function () {
            $transformer = new DecimalPriceTransformer('USD', 'en_US', 2);

            // Test the same edge cases
            $edgeCases = [
                19.995,  // Should round to 20.00
                19.994,  // Should round to 19.99
                0.005,   // Should round to 0.01
                0.004,   // Should round to 0.00
            ];

            foreach ($edgeCases as $price) {
                $stored = $transformer->toStorage($price);
                $displayed = $transformer->toDisplay($stored);

                // Should be properly rounded floats
                expect($stored)->toBeFloat();
                // Display should show proper decimal places
                expect($displayed)->toMatch('/^\d+\.\d{2}$/');
            }
        });
    });
});
