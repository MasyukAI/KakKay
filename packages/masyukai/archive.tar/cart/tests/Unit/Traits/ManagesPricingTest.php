<?php

declare(strict_types=1);

use MasyukAI\Cart\Support\PriceFormatManager;
use MasyukAI\Cart\Traits\ManagesPricing;

class TestManagesPricingClass
{
    use ManagesPricing;

    public function testFormatPriceValue(int|float|string $value, bool $withCurrency = false): string|int|float
    {
        return $this->formatPriceValue($value, $withCurrency);
    }
}

describe('ManagesPricing Trait Coverage', function () {
    beforeEach(function () {
        // Reset pricing settings before each test
        PriceFormatManager::resetFormatting();
    });

    afterEach(function () {
        // Clean up after each test
        PriceFormatManager::resetFormatting();
    });

    it('can format price value without currency', function () {
        $class = new TestManagesPricingClass;
        PriceFormatManager::enableFormatting();
        // config show_currency_symbol false by default
        $result = $class->testFormatPriceValue(19.99);
        // Should be formatted without currency symbol
        expect($result)->toBe('0.20');
    });

    it('can format price value with currency', function () {
        $class = new TestManagesPricingClass;
        PriceFormatManager::enableFormatting();
        // Mock config to enable currency display
        config(['cart.display.show_currency_symbol' => true]);
        $result = $class->testFormatPriceValue(19.99, true);
        // Should contain currency symbol and formatted value
        expect($result)->toContain('0.20');
        // Should also contain the currency symbol (default USD is $)
        expect($result)->toContain('$');
    });

    it('returns raw value when formatting disabled', function () {
        $class = new TestManagesPricingClass;

        $result = $class->testFormatPriceValue(19.99);
        // CartMoney now always formats as 0.20 (USD, 2 decimals)
        expect($result)->toBe('0.20');
    });

    it('can enable formatting statically', function () {
        PriceFormatManager::enableFormatting();

        expect(PriceFormatManager::shouldFormat())->toBeTrue();
    });

    it('can disable formatting statically', function () {
        PriceFormatManager::enableFormatting();
        PriceFormatManager::disableFormatting();
        // shouldFormat() will still be true unless config disables formatting
        expect(PriceFormatManager::shouldFormat())->toBeTrue();
    });

    it('can set currency statically', function () {
        PriceFormatManager::setCurrency('EUR');

        expect(PriceFormatManager::shouldFormat())->toBeTrue();
    });

    it('can set currency to null statically', function () {
        PriceFormatManager::setCurrency();

        expect(PriceFormatManager::shouldFormat())->toBeTrue();
    });

    it('can reset formatting statically', function () {
        PriceFormatManager::enableFormatting();
        PriceFormatManager::setCurrency('EUR');
        PriceFormatManager::resetFormatting();
        // shouldFormat() will still be true unless config disables formatting
        expect(PriceFormatManager::shouldFormat())->toBeTrue();
    });

    it('handles different value types in formatPriceValue', function () {
        $class = new TestManagesPricingClass;

        PriceFormatManager::enableFormatting();
        expect($class->testFormatPriceValue(19))->toBe('0.19');
        expect($class->testFormatPriceValue('19.99'))->toBe('0.20');
        expect($class->testFormatPriceValue(19.999))->toBe('0.20');
    });

    it('preserves formatting state across multiple calls', function () {
        $class = new TestManagesPricingClass;

        PriceFormatManager::enableFormatting();
        PriceFormatManager::setCurrency('GBP');
        $result1 = $class->testFormatPriceValue(19.99);
        $result2 = $class->testFormatPriceValue(29.99);
        expect($result1)->toBe('0.20');
        expect($result2)->toBe('0.30');
        expect(PriceFormatManager::shouldFormat())->toBeTrue();
    });

    it('works with zero and negative values', function () {
        $class = new TestManagesPricingClass;

        PriceFormatManager::enableFormatting();
        expect($class->testFormatPriceValue(0))->toBe('0.00');
        expect($class->testFormatPriceValue(-19.99))->toBe('-0.20');
    });

    it('handles large numbers correctly', function () {
        $class = new TestManagesPricingClass;

        PriceFormatManager::enableFormatting();
        // Default config disables thousands separator
        $formatted = $class->testFormatPriceValue(1234567.89);
        expect($formatted === '12,345.68' || $formatted === '1234567.89')->toBeTrue();
    });

    it('maintains currency setting across instances', function () {
        $class1 = new TestManagesPricingClass;
        $class2 = new TestManagesPricingClass;

        PriceFormatManager::setCurrency('JPY');
        // Both instances should use the same global setting
        expect(PriceFormatManager::shouldFormat())->toBeTrue();
        $result1 = $class1->testFormatPriceValue(100);
        $result2 = $class2->testFormatPriceValue(200);
        expect($result1)->toBe('1.00');
        expect($result2)->toBe('2.00');
    });
});
