<?php

declare(strict_types=1);

use MasyukAI\Cart\Cart;
use MasyukAI\Cart\PriceTransformers\IntegerPriceTransformer;
use MasyukAI\Cart\Services\PriceFormatterService;
use MasyukAI\Cart\Storage\SessionStorage;

it('debugs subtotal calculation step by step (config-independent)', function () {
    // Create cart with explicit dependencies (no config)
    $session = app('session')->driver();
    $storage = new SessionStorage($session, 'debug_subtotal_test');
    $cart = new Cart(
        storage: $storage,
        events: new \Illuminate\Events\Dispatcher,
        instanceName: 'debug_subtotal_test',
        eventsEnabled: false
    );

    // Add item to cart
    $cart->add('1', 'Test Product', 19.99, 1);
    $cartItem = $cart->getItems()->first();

    // Debug the exact values and transformations
    expect($cartItem->price)->toBeFloat();
    expect($cartItem->quantity)->toBe(1);

    // Get the raw sum before any transformations
    $rawSum = $cartItem->getRawPriceSum();
    expect($rawSum)->toBeFloat();
    expect(gettype($rawSum))->toBe('double');

    // Test cart subtotal - should be numeric (raw) by default
    expect($cart->subtotal()->getMajorUnits())->toBe(19.99);

    // Test with explicit formatter (IntegerPriceTransformer)
    $transformer = new IntegerPriceTransformer('USD', 'en_US', 2);
    $formatter = new PriceFormatterService($transformer);

    // Test formatter behavior
    expect($formatter->format($rawSum))->toBeString();
    expect($formatter->format($rawSum))->toBe('19.99');

    // Test normalization (convert to storage format)
    expect($formatter->normalize(19.99))->toBe(1999);

    // This demonstrates the cart works correctly with both raw calculations
    // and explicit price transformer formatting
    expect(true)->toBeTrue();
});
