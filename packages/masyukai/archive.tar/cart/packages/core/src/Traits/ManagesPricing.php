<?php

declare(strict_types=1);

namespace MasyukAI\Cart\Traits;

use MasyukAI\Cart\Support\CartMoney;

trait ManagesPricing
{
    /**
     * Create CartMoney object from price value
     */
    protected function createMoney(int|float|string $value, ?string $currency = null, ?int $precision = null): CartMoney
    {
        // Apply precision if specified before creating CartMoney
        if ($precision !== null && is_numeric($value)) {
            $value = round((float) $value, $precision);
        }

        return CartMoney::fromMajorUnits($value, $currency);
    }

    /**
     * Format CartMoney object for display
     */
    protected function formatMoney(CartMoney $money, bool $withCurrency = true): string
    {
        if (! $this->isFormattingEnabled()) {
            return (string) $money->getMajorUnits();
        }

        return $withCurrency && $this->shouldShowCurrencySymbol()
            ? $money->format()
            : $money->formatWithoutCurrency();
    }

    /**
     * Format price value - creates CartMoney for precision and formatting
     */
    protected function formatPriceValue(int|float|string $value, bool $withCurrency = false): string|float
    {
        if (! $this->isFormattingEnabled()) {
            return is_numeric($value) ? (float) $value : 0.0;
        }

        $money = CartMoney::fromMajorUnits($value);

        return $withCurrency && $this->shouldShowCurrencySymbol()
            ? $money->format()
            : $money->formatWithoutCurrency();
    }

    /**
     * Get default currency
     */
    protected function getDefaultCurrency(): string
    {
        return config('cart.money.default_currency', 'USD');
    }

    /**
     * Check if formatting is enabled
     */
    protected function isFormattingEnabled(): bool
    {
        return config('cart.display.formatting_enabled', true);
    }

    /**
     * Get display locale
     */
    protected function getDisplayLocale(): string
    {
        return config('cart.display.locale', 'en_US');
    }

    /**
     * Check if currency symbol should be shown
     */
    protected function shouldShowCurrencySymbol(): bool
    {
        return config('cart.display.currency_symbol', true);
    }

    /**
     * Get default precision for Money objects
     */
    protected function getDefaultPrecision(): int
    {
        return config('cart.money.default_precision', 2);
    }

    /**
     * Convert old Money to new CartMoney (for migration)
     */
    protected function migrateOldMoney(\MasyukAI\Cart\Support\Money $oldMoney): CartMoney
    {
        return CartMoney::fromOldMoney($oldMoney);
    }
}
