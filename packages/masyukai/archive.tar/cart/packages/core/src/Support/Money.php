<?php

declare(strict_types=1);

namespace MasyukAI\Cart\Support;

use InvalidArgumentException;
use JsonSerializable;
use Stringable;

/**
 * Immutable Money value object for precision arithmetic
 * All internal calculations use integer minor units (cents)
 */
class Money implements JsonSerializable, Stringable
{
    public readonly int $amount;

    public readonly string $currency;

    public readonly int $precision;

    private function __construct(
        int $amount,
        string $currency,
        int $precision
    ) {
        if ($precision < 0 || $precision > 6) {
            throw new InvalidArgumentException('Precision must be between 0 and 6');
        }

        $this->currency = strtoupper($currency);
        $this->precision = $precision;
        $this->amount = $amount;
    }

    /**
     * Create Money from minor units (cents)
     */
    public static function fromMinorUnits(int $amount, string $currency = 'USD', int $precision = 2): self
    {
        return new self($amount, $currency, $precision);
    }

    /**
     * Create Money from major units (dollars)
     */
    public static function fromMajorUnits(int|float|string $amount, string $currency = 'USD', int $precision = 2): self
    {
        $minorAmount = self::parseAmount($amount, $precision);

        return new self($minorAmount, $currency, $precision);
    }

    /**
     * Parse amount string/float/int into minor units
     */
    private static function parseAmount(int|float|string $amount, int $precision): int
    {
        if (is_int($amount)) {
            return $amount * (10 ** $precision);
        }

        if (is_float($amount)) {
            return (int) round($amount * (10 ** $precision));
        }

        // Handle string amounts - clean and parse
        $cleaned = preg_replace('/[^\d.-]/', '', $amount);
        $float = (float) $cleaned;

        return (int) round($float * (10 ** $precision));
    }

    /**
     * Add another Money amount
     */
    public function add(Money $other): self
    {
        $this->assertSameCurrency($other);

        return self::fromMinorUnits(
            $this->amount + $other->amount,
            $this->currency,
            $this->precision
        );
    }

    /**
     * Subtract another Money amount
     */
    public function subtract(Money $other): self
    {
        $this->assertSameCurrency($other);

        return self::fromMinorUnits(
            $this->amount - $other->amount,
            $this->currency,
            $this->precision
        );
    }

    /**
     * Multiply by a factor
     */
    public function multiply(int|float $factor): self
    {
        // Use higher precision for intermediate calculation to avoid precision loss
        $result = $this->amount * $factor;

        // For very small results that would round to 0, we need to decide:
        // If the result is between -0.5 and 0.5, round normally
        // This preserves the mathematical accuracy for Money operations
        return self::fromMinorUnits(
            (int) round($result),
            $this->currency,
            $this->precision
        );
    }

    /**
     * Divide by a factor
     */
    public function divide(int|float $divisor): self
    {
        if ($divisor == 0) {
            throw new InvalidArgumentException('Cannot divide by zero');
        }

        return self::fromMinorUnits(
            (int) round($this->amount / $divisor),
            $this->currency,
            $this->precision
        );
    }

    /**
     * Calculate percentage
     */
    public function percentage(int|float $percentage): self
    {
        return $this->multiply($percentage / 100);
    }

    /**
     * Compare with another Money amount
     */
    public function equals(Money $other): bool
    {
        return $this->currency === $other->currency && $this->amount === $other->amount;
    }

    /**
     * Check if greater than another amount
     */
    public function greaterThan(Money $other): bool
    {
        $this->assertSameCurrency($other);

        return $this->amount > $other->amount;
    }

    /**
     * Check if less than another amount
     */
    public function lessThan(Money $other): bool
    {
        $this->assertSameCurrency($other);

        return $this->amount < $other->amount;
    }

    /**
     * Check if zero or negative
     */
    public function isZeroOrNegative(): bool
    {
        return $this->amount <= 0;
    }

    /**
     * Check if positive
     */
    public function isPositive(): bool
    {
        return $this->amount > 0;
    }

    /**
     * Get absolute value
     */
    public function abs(): self
    {
        return self::fromMinorUnits(
            abs($this->amount),
            $this->currency,
            $this->precision
        );
    }

    /**
     * Get amount in minor units (cents)
     */
    public function getMinorUnits(): int
    {
        return $this->amount;
    }

    /**
     * Get amount in major units (dollars)
     */
    public function getMajorUnits(): float
    {
        return $this->amount / (10 ** $this->precision);
    }

    /**
     * Get currency code
     */
    public function getCurrency(): string
    {
        return $this->currency;
    }

    /**
     * Get precision
     */
    public function getPrecision(): int
    {
        return $this->precision;
    }

    /**
     * Format as currency string
     */
    public function format(?string $locale = null): string
    {
        $locale = $locale ?? 'en_US';
        $formatter = new \NumberFormatter($locale, \NumberFormatter::CURRENCY);

        return $formatter->formatCurrency($this->getMajorUnits(), $this->currency);
    }

    /**
     * Format without currency symbol
     */
    public function formatWithoutCurrency(?string $locale = null): string
    {
        $locale = $locale ?? 'en_US';
        $formatter = new \NumberFormatter($locale, \NumberFormatter::DECIMAL);
        $formatter->setAttribute(\NumberFormatter::FRACTION_DIGITS, $this->precision);
        $formatter->setAttribute(\NumberFormatter::GROUPING_USED, 0); // Disable thousand separators

        return $formatter->format($this->getMajorUnits());
    }

    /**
     * Convert to array for serialization
     */
    public function toArray(): array
    {
        return [
            'amount' => $this->amount,
            'currency' => $this->currency,
            'precision' => $this->precision,
            'formatted' => $this->format(),
        ];
    }

    /**
     * JSON serialization
     */
    public function jsonSerialize(): array
    {
        return $this->toArray();
    }

    /**
     * String representation
     */
    public function __toString(): string
    {
        return $this->format();
    }

    /**
     * Assert currencies match for operations
     */
    private function assertSameCurrency(Money $other): void
    {
        if ($this->currency !== $other->currency) {
            throw new InvalidArgumentException(
                "Currency mismatch: {$this->currency} vs {$other->currency}"
            );
        }
    }
}
