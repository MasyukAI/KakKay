<?php

declare(strict_types=1);

namespace MasyukAI\Cart\Support;

use MasyukAI\Cart\Cart;
use MasyukAI\Cart\Models\CartItem;
use MasyukAI\Cart\Storage\StorageInterface;

/**
 * Money-aware adapter for precise cart calculations
 *
 * This adapter wraps the existing cart system with Money value objects
 * to provide precision arithmetic without breaking existing functionality.
 * For standalone use without Laravel context.
 *
 * @example
 * $moneyCart = new MoneyCartAdapter('default');
 * $subtotal = $moneyCart->getSubtotalMoney(); // Returns Money object
 * $total = $moneyCart->getTotalMoney();       // Returns Money object
 */
class MoneyCartAdapter
{
    private Cart $cart;

    private string $currency;

    private int $precision;

    public function __construct(
        string $instance = 'default',
        string $currency = 'USD',
        int $precision = 2
    ) {
        // Create a simple cart instance for demonstration
        $this->cart = new Cart(
            storage: new class implements StorageInterface
            {
                private array $data = [];

                public function has(string $identifier, string $instance): bool
                {
                    return isset($this->data[$identifier][$instance]);
                }

                public function forget(string $identifier, string $instance): void
                {
                    unset($this->data[$identifier][$instance]);
                }

                public function flush(): void
                {
                    $this->data = [];
                }

                public function getInstances(string $identifier): array
                {
                    return array_keys($this->data[$identifier] ?? []);
                }

                public function forgetIdentifier(string $identifier): void
                {
                    unset($this->data[$identifier]);
                }

                public function getItems(string $identifier, string $instance): array
                {
                    return $this->data[$identifier][$instance]['items'] ?? [];
                }

                public function putItems(string $identifier, string $instance, array $items): void
                {
                    $this->data[$identifier][$instance]['items'] = $items;
                }

                public function getConditions(string $identifier, string $instance): array
                {
                    return $this->data[$identifier][$instance]['conditions'] ?? [];
                }

                public function putConditions(string $identifier, string $instance, array $conditions): void
                {
                    $this->data[$identifier][$instance]['conditions'] = $conditions;
                }

                public function putBoth(string $identifier, string $instance, array $items, array $conditions): void
                {
                    $this->data[$identifier][$instance]['items'] = $items;
                    $this->data[$identifier][$instance]['conditions'] = $conditions;
                }

                public function putMetadata(string $identifier, string $instance, string $key, mixed $value): void
                {
                    $this->data[$identifier][$instance]['metadata'][$key] = $value;
                }

                public function getMetadata(string $identifier, string $instance, string $key): mixed
                {
                    return $this->data[$identifier][$instance]['metadata'][$key] ?? null;
                }

                public function swapIdentifier(string $oldIdentifier, string $newIdentifier, string $instance): bool
                {
                    if (isset($this->data[$oldIdentifier][$instance])) {
                        $this->data[$newIdentifier][$instance] = $this->data[$oldIdentifier][$instance];
                        unset($this->data[$oldIdentifier][$instance]);

                        return true;
                    }

                    return false;
                }
            },
            instanceName: $instance
        );
        $this->currency = $currency;
        $this->precision = $precision;
    }

    /**
     * Add item to cart with Money price
     */
    public function addMoney(
        string $id,
        string $name,
        Money $price,
        int $quantity = 1,
        array $attributes = []
    ): CartItem {
        // Convert Money to float for existing cart system
        $floatPrice = $price->getMajorUnits();

        return $this->cart->add($id, $name, $floatPrice, $quantity, $attributes);
    }

    /**
     * Get cart subtotal as Money object
     */
    public function getSubtotalMoney(): Money
    {
        $floatSubtotal = $this->cart->getRawSubtotal();

        return Money::fromMajorUnits($floatSubtotal, $this->currency, $this->precision);
    }

    /**
     * Get cart total as Money object
     */
    public function getTotalMoney(): Money
    {
        $floatTotal = $this->cart->getRawTotal();

        return Money::fromMajorUnits($floatTotal, $this->currency, $this->precision);
    }

    /**
     * Get item subtotal as Money object
     */
    public function getItemSubtotalMoney(string $itemId): ?Money
    {
        $item = $this->cart->get($itemId);
        if (! $item) {
            return null;
        }

        $floatSubtotal = $item->getRawPriceSum();

        return Money::fromMajorUnits($floatSubtotal, $this->currency, $this->precision);
    }

    /**
     * Calculate tax amount as Money object
     */
    public function calculateTaxMoney(float $taxRate): Money
    {
        $subtotal = $this->getSubtotalMoney();

        return $subtotal->percentage($taxRate);
    }

    /**
     * Calculate discount amount as Money object
     */
    public function calculateDiscountMoney(float $discountRate): Money
    {
        $subtotal = $this->getSubtotalMoney();

        return $subtotal->percentage($discountRate);
    }

    /**
     * Get total with precise tax calculation
     */
    public function getTotalWithTaxMoney(float $taxRate): Money
    {
        $subtotal = $this->getSubtotalMoney();
        $tax = $subtotal->percentage($taxRate);

        return $subtotal->add($tax);
    }

    /**
     * Get total with precise discount calculation
     */
    public function getTotalWithDiscountMoney(float $discountRate): Money
    {
        $subtotal = $this->getSubtotalMoney();
        $discount = $subtotal->percentage($discountRate);

        return $subtotal->subtract($discount);
    }

    /**
     * Apply shipping cost using Money precision
     */
    public function addShippingMoney(Money $shippingCost): Money
    {
        $total = $this->getTotalMoney();

        return $total->add($shippingCost);
    }

    /**
     * Get all item prices as Money objects
     */
    public function getItemPricesMoney(): array
    {
        $items = $this->cart->getItems();
        $moneyPrices = [];

        foreach ($items as $item) {
            $moneyPrices[$item->id] = [
                'unit_price' => Money::fromMajorUnits($item->getRawPriceWithoutConditions(), $this->currency, $this->precision),
                'subtotal' => Money::fromMajorUnits($item->getRawPriceSum(), $this->currency, $this->precision),
                'quantity' => $item->quantity,
            ];
        }

        return $moneyPrices;
    }

    /**
     * Compare cart total with expected Money amount
     */
    public function verifyTotal(Money $expectedTotal): bool
    {
        $actualTotal = $this->getTotalMoney();

        return $actualTotal->equals($expectedTotal);
    }

    /**
     * Get price breakdown with Money precision
     */
    public function getPriceBreakdownMoney(): array
    {
        return [
            'subtotal' => $this->getSubtotalMoney(),
            'total' => $this->getTotalMoney(),
            'currency' => $this->currency,
            'precision' => $this->precision,
            'items_count' => $this->cart->countItems(),
            'total_quantity' => $this->cart->getTotalQuantity(),
        ];
    }

    /**
     * Apply a cart condition with Money precision
     */
    public function applyMoneyCondition(string $name, Money $amount, string $type = 'discount'): void
    {
        $floatValue = $amount->getMajorUnits();
        $value = $type === 'discount' ? "-{$floatValue}" : "+{$floatValue}";

        $this->cart->addCondition([
            'name' => $name,
            'type' => $type,
            'value' => $value,
        ]);
    }

    /**
     * Access underlying cart instance
     */
    public function getCartInstance(): Cart
    {
        return $this->cart;
    }

    /**
     * Get currency being used
     */
    public function getCurrency(): string
    {
        return $this->currency;
    }

    /**
     * Get precision being used
     */
    public function getPrecision(): int
    {
        return $this->precision;
    }

    /**
     * Set different currency
     */
    public function setCurrency(string $currency): self
    {
        $this->currency = $currency;

        return $this;
    }

    /**
     * Set different precision
     */
    public function setPrecision(int $precision): self
    {
        $this->precision = $precision;

        return $this;
    }
}
