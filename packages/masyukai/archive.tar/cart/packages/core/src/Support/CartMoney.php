<?php

declare(strict_types=1);

namespace MasyukAI\Cart\Support;

use Akaunting\Money\Currency;
use Akaunting\Money\Money;
use InvalidArgumentException;
use JsonSerializable;
use Stringable;

/**
 * Cart Money wrapper for Laravel Money
 * Provides cart-specific functionality while leveraging Laravel Money's power
 */
class CartMoney implements JsonSerializable, Stringable
{
    private Money $money;

    private function __construct(Money $money)
    {
        $this->money = $money;
    }

    /**
     * Create Money from minor units (cents)
     */
    public static function fromMinorUnits(int $amount, ?string $currency = null, ?int $precision = null): self
    {
        $currency = $currency ?? config('cart.money.default_currency', 'USD');
        $precision = $precision ?? config('cart.money.default_precision', 2);

        // Convert minor units to major units for Laravel Money
        $majorAmount = $amount / (10 ** $precision);

        return new self(new Money($majorAmount, new Currency($currency)));
    }

    /**
     * Create Money from major units (dollars)
     */
    public static function fromMajorUnits(int|float|string $amount, ?string $currency = null): self
    {
        $currency = $currency ?? config('cart.money.default_currency', 'USD');

        // Parse the amount if it's a string
        if (is_string($amount)) {
            $amount = self::parseAmount($amount);
        }

        return new self(new Money($amount, new Currency($currency)));
    }

    /**
     * Create Money from array (for unserialization)
     */
    public static function fromArray(array $data): self
    {
        return self::fromMinorUnits(
            $data['amount'] ?? 0,
            $data['currency'] ?? null
        );
    }

    /**
     * Parse amount string into float
     */
    private static function parseAmount(string $amount): float
    {
        // Remove currency symbols and non-numeric chars except dots and minus
        $cleaned = preg_replace('/[^\d.-]/', '', $amount);

        return (float) $cleaned;
    }

    /**
     * Add another Money amount
     */
    public function add(self $other): self
    {
        return new self($this->money->add($other->money));
    }

    /**
     * Subtract another Money amount
     */
    public function subtract(self $other): self
    {
        return new self($this->money->subtract($other->money));
    }

    /**
     * Multiply by a factor
     */
    public function multiply(int|float $factor): self
    {
        return new self($this->money->multiply($factor));
    }

    /**
     * Divide by a factor
     */
    public function divide(int|float $divisor): self
    {
        if ($divisor == 0) {
            throw new InvalidArgumentException('Cannot divide by zero');
        }

        return new self($this->money->divide($divisor));
    }

    /**
     * Calculate percentage
     */
    public function percentage(int|float $percentage): self
    {
        return $this->multiply($percentage / 100);
    }

    /**
     * Compare with another Money amount
     */
    public function equals(self $other): bool
    {
        return $this->money->compare($other->money) === 0;
    }

    /**
     * Check if greater than another amount
     */
    public function greaterThan(self $other): bool
    {
        return $this->money->compare($other->money) > 0;
    }

    /**
     * Check if less than another amount
     */
    public function lessThan(self $other): bool
    {
        return $this->money->compare($other->money) < 0;
    }

    /**
     * Check if zero or negative
     */
    public function isZeroOrNegative(): bool
    {
        return $this->money->isNegative() || $this->money->isZero();
    }

    /**
     * Check if positive
     */
    public function isPositive(): bool
    {
        return $this->money->isPositive();
    }

    /**
     * Check if zero
     */
    public function isZero(): bool
    {
        return $this->money->isZero();
    }

    /**
     * Get absolute value
     */
    public function abs(): self
    {
        return new self($this->money->absolute());
    }

    /**
     * Round to given precision
     */
    public function round(int $precision = 2): self
    {
        // Laravel Money doesn't have a round method, so we'll create a new Money object
        $rounded = round($this->money->getAmount(), $precision);

        return new self(new Money($rounded, $this->money->getCurrency()));
    }

    /**
     * Get amount in minor units (cents)
     */
    public function getMinorUnits(): int
    {
        $precision = config('cart.money.default_precision', 2);

        return (int) round($this->money->getAmount() * (10 ** $precision));
    }

    /**
     * Get amount in major units (dollars)
     */
    public function getMajorUnits(): float
    {
        return $this->money->getAmount();
    }

    /**
     * Get currency code
     */
    public function getCurrency(): string
    {
        // Laravel Money returns the currency code directly as string
        return $this->money->getCurrency()->getCurrency();
    }

    /**
     * Get precision from config
     */
    public function getPrecision(): int
    {
        return config('cart.money.default_precision', 2);
    }

    /**
     * Format as currency string using config
     */
    public function format(?string $locale = null): string
    {
        $locale = $locale ?? config('cart.display.locale', 'en_US');

        // Use Laravel Money's formatting with our config
        return $this->money->format($locale);
    }

    /**
     * Format without currency symbol
     */
    public function formatWithoutCurrency(?string $locale = null): string
    {
        $locale = $locale ?? config('cart.display.locale', 'en_US');

        // Use formatSimple which doesn't include currency symbol
        return $this->money->formatSimple();
    }

    /**
     * Format using config options
     */
    public function formatByConfig(): string
    {
        $locale = config('cart.display.locale', 'en_US');
        $formatStyle = config('cart.display.format_style', 'currency');

        return match ($formatStyle) {
            'decimal' => $this->formatWithoutCurrency($locale),
            'accounting' => $this->money->formatByDecimal($locale, config('cart.money.default_precision', 2)),
            default => $this->format($locale),
        };
    }

    /**
     * Convert to array for serialization
     */
    public function toArray(): array
    {
        return [
            'amount' => $this->getMinorUnits(),
            'currency' => $this->getCurrency(),
            'precision' => $this->getPrecision(),
            'formatted' => $this->format(),
            'major_units' => $this->getMajorUnits(),
        ];
    }

    /**
     * JSON serialization
     */
    public function jsonSerialize(): array
    {
        return $this->toArray();
    }

    /**
     * String representation
     */
    public function __toString(): string
    {
        return $this->formatByConfig();
    }

    /**
     * Get the underlying Laravel Money object
     */
    public function getMoney(): Money
    {
        return $this->money;
    }

    /**
     * Convert our old Money objects to new CartMoney
     */
    public static function fromOldMoney(\MasyukAI\Cart\Support\Money $oldMoney): self
    {
        return self::fromMinorUnits(
            $oldMoney->getMinorUnits(),
            $oldMoney->getCurrency(),
            $oldMoney->getPrecision()
        );
    }
}
