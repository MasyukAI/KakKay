<?php

declare(strict_types=1);

namespace MasyukAI\Cart\Listeners;

use MasyukAI\Cart\Support\PriceFormatManager;

class ResetCartState
{
    /**
     * Handle the operation terminated event.
     * This resets any static state to prevent memory leaks in Octane.
     */
    public function handle(): void
    {
        // Reset static state in PriceFormatManager
        PriceFormatManager::resetFormatting();
    }
}
