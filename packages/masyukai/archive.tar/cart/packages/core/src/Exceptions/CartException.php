<?php

declare(strict_types=1);

namespace MasyukAI\Cart\Exceptions;

use Exception;

class CartException extends Exception
{
    //
}
